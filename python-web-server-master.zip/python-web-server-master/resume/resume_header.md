_[Home](/)_ _[Blog](/blog/)_ __[Resume](/resume)__

---
