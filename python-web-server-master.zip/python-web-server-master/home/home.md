Welcome to Sam's website!

You're probably here for the [blog posts](/blog/), but feel free to look around.

The code powering this site lives on [GitHub](https://github.com/samervin/python-web-server).
