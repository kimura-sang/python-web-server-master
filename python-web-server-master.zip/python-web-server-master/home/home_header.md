__[Home](/)__ _[Blog](/blog/)_ _[Resume](/resume)_

---
