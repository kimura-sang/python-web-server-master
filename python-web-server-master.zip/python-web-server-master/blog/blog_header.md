_[Home](/)_ __[Blog](/blog/)__ _[Resume](/resume)_

---
